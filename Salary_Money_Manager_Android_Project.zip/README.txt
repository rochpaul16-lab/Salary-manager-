# Salary & Money Manager — Android App

This is an Android Studio project wrapping the Salary & Money Manager web app in a native Android WebView.

## Build
1. Install Android Studio.
2. Open this folder as a project.
3. Let Gradle sync.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.
6. To create an APK: Build > Build APK(s).

The app stores its data locally on the device using browser localStorage inside WebView.
